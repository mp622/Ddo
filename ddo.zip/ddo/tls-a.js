const http = require('http'),
    cluster = require('cluster'),
    fs = require('fs');

let target = process.argv[2],
    thread = process.argv[3],
    proxys = fs.readFileSync(process.argv[4], 'utf-8').toString().match(/\S+/g);

function proxyr() {
    return proxys[Math.floor(Math.random() * proxys.length)];
}

if (cluster.isMaster) {
    console.log(`Target: ${target} | Threads: ${thread}`);

    for (var bb = 0; bb < thread; bb++) {
        cluster.fork();
    }
} else {
    const server = http.createServer((req, res) => {
        let proxy = proxyr().split(':');

        const options = {
            hostname: target,
            port: 80,
            path: req.url,
            method: req.method,
            headers: req.headers
        };

        const proxyReq = http.request(options, (proxyRes) => {
            res.writeHead(proxyRes.statusCode, proxyRes.headers);
            proxyRes.pipe(res, {
                end: true
            });
        });

        req.pipe(proxyReq, {
            end: true
        });

        proxyReq.on('error', (e) => {
            console.error(`problem with request: ${e.message}`);
            res.writeHead(500);
            res.end(`Got error: ${e.message}`);
        });
    });

    server.listen(80, (err) => {
        if (err) {
            console.error(err);
        } else {
            console.log(`Server running on port 80`);
        }
    });
}
