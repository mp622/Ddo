#New User Pass 
User : nxt
pass : nxt

#New Proxy !

#New Methods !

#Setup Guide

- install python 3.11
- install nodejs
+ python installer.py
+ python nxt-enc.py

#TELEGRAM GROUP : https://t.me/+SchnHiumuzY4M2Rl

# YOUTUBE DEMO : https://youtu.be/pHl7IjlvS6I

#THANK YOU ALL , PANEL FREE !
